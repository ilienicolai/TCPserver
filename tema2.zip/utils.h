#define MAX_CONNECTIONS 128
#define MAX_TOPIC 51
#define MAX_ID_LEN 10
#define MAX_UDP_SIZE 1552
#define MAX_UDP_PAYLOAD 1500
#define MAX_TCP_PAYLOAD 1601
/*
 * Macro de verificare a erorilor
 * Exemplu:
 * 		int fd = open (file_name , O_RDONLY);
 * 		DIE( fd == -1, "open failed");
 */

#define DIE(assertion, call_description)                                       \
  do {                                                                         \
    if (assertion) {                                                           \
      fprintf(stderr, "(%s, %d): ", __FILE__, __LINE__);                       \
      perror(call_description);                                                \
      exit(EXIT_FAILURE);                                                      \
    }                                                                          \
  } while (0)

struct topic_udp {
    char topic[MAX_TOPIC];
    unsigned char type;
    char payload[MAX_UDP_PAYLOAD];
};

struct tcp_struct {
    int type;
    char payload[MAX_TCP_PAYLOAD];
};

