#include <iostream>
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <vector>
#include <algorithm>
#include <cstring>
#include <unordered_map>
#include <iomanip>
#include "utils.h"

using namespace std;
string lowercase(string str) {

    // Iterate all characters, transform all to lowercase.
    for (auto& c : str) {
        c = (char) tolower(c);
    }
    return str;
}
vector<string> split_command(string command, string delim) {

    // Initialize the empty vector for the tokens.
    vector<string> result;
    char *command_copy = (char *) command.c_str();
    char *delim_copy = (char *) delim.c_str();

    // Standard splitting algorithm.
    char *token = strtok(command_copy, delim_copy);
    while (token != nullptr) {
        result.emplace_back(token);
        token = strtok(nullptr, delim_copy);
    }

    return result;
}

bool is_string_number(string str) {
    int start_index = 0;

    if (str[0] == '-') {
        start_index = 1;
    }

    for (long unsigned int i = start_index; i < str.length(); i++) {
        if (!isdigit(str[i])) {
            return false;
        }
    }
    return true;
}
int main(int argc, char *argv[]) {
    // Handle argument errors.
    if (argc != 4) {
        cerr << "Usage: " << argv[0] << " id_client ip_server port_server" << endl;
        exit(0);
    }
    // Disable buffering.
    
    setvbuf(stdout, nullptr, _IONBF, BUFSIZ);
    int rc;
    uint16_t port;
    port = stoi(argv[3]);
    DIE(port < 0, "port");

    int sockfd, flag;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    DIE(sockfd < 0, "socket");

    struct sockaddr_in serv_addr;
    socklen_t socket_len = sizeof(struct sockaddr_in);
    memset(&serv_addr, 0, socket_len);

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    rc = inet_aton(argv[2], &serv_addr.sin_addr);
    DIE(rc < 0, "inet_aton");
    //cout << "Connect to server" << endl;
    // Ne conectăm la server
    rc = connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
    DIE(rc < 0, "connect");

    // Disable Nagle's algorithm.
    flag = 1;
    rc = setsockopt(sockfd, IPPROTO_TCP, TCP_NODELAY, (char *) &flag, sizeof(int));
    DIE(rc < 0, "nagle");

    // Allocate memory for the client ID.
    auto *tcp_client_id = new char[MAX_ID_LEN + 1];
    memset(tcp_client_id, 0, MAX_ID_LEN + 1);
    // Copy the client ID.
    memcpy(tcp_client_id, argv[1], strlen(argv[1]));

    // Create a new tcp message.
    auto *tcp_client_connect_msg = new tcp_struct;
    memset(tcp_client_connect_msg, 0, sizeof(struct tcp_struct));
    tcp_client_connect_msg->type = 0;

    // Copy the client ID in the payload.
    memcpy(tcp_client_connect_msg->payload, tcp_client_id, MAX_ID_LEN + 1);
    // Send the connect message to the server.
    rc = (int) send(sockfd, tcp_client_connect_msg, sizeof(tcp_struct), 0);
    DIE(rc < 0, "connect id");

    struct pollfd poll_fds[2];
    poll_fds[0].fd = sockfd;
    poll_fds[0].events = POLLIN;
    poll_fds[1].fd = STDIN_FILENO;
    poll_fds[1].events = POLLIN;
    int num_sockets = 2;
    bool loop = true;
    while (loop) {
        rc = poll(poll_fds, num_sockets, -1);
        DIE(rc < 0, "poll");

        for (int i = 0; i < num_sockets; i++) {
            if (poll_fds[i].revents & POLLIN) {
                if (poll_fds[i].fd == STDIN_FILENO) {
                    // Get the input.
                    string command_line;
                    getline(cin, command_line);
                    // Split the input into command and arguments.
                    auto command_args = split_command(command_line, " ");

                    // Handle exit command.
                    if (lowercase(command_args[0]) == "exit") {
                        loop = false;
                        break;
                    }
                    if (lowercase(command_args[0]) == "subscribe") {
                        // Check if the command has the correct number of arguments.
                        if (command_args.size() != 2) {
                            cerr << "Usage: subscribe topic SF" << endl;
                            continue;
                        }
                        // Create a new tcp message.
                        auto *tcp_client_subscribe_msg = new tcp_struct;
                        memset(tcp_client_subscribe_msg, 0, sizeof(struct tcp_struct));
                        tcp_client_subscribe_msg->type = 1;
                        // Check if the topic name is longer than the maximum length.
                        char *topic_name = (char *) command_args[1].c_str();
                        if (strlen(topic_name) > MAX_TOPIC - 1) {
                            continue;
                        }
                        // Copy the topic in the payload.
                        memcpy(tcp_client_subscribe_msg->payload, topic_name, strlen(topic_name));
                        // Send the subscribe message to the server.
                        rc = (int) send(sockfd, tcp_client_subscribe_msg, sizeof(tcp_struct), 0);
                        DIE(rc < 0, "subscribe");
                        // Server sends subscribe confirmation.
                        int reply;
                        rc = (int) recv(sockfd, &reply, 4, 0);
                        DIE(rc < 0, "receive");

                        // Output success message.
                        if (reply == 1) {
                            cout << "Subscribed to topic " << command_args[1].c_str() << endl;
                        }
                        continue;
                    }
                    if (lowercase(command_args[0]) == "unsubscribe") {
                        // Check if the command has the correct number of arguments.
                        if (command_args.size() != 2) {
                            cerr << "Usage: unsubscribe topic" << endl;
                            continue;
                        }
                        // Create a new tcp message.
                        auto *tcp_client_unsubscribe_msg = new tcp_struct;
                        memset(tcp_client_unsubscribe_msg, 0, sizeof(struct tcp_struct));
                        tcp_client_unsubscribe_msg->type = -1;
                        // Check if the topic name is longer than the maximum length.
                        char *topic_name = (char *) command_args[1].c_str();
                        if (strlen(topic_name) > MAX_TOPIC - 1) {
                            continue;
                        }
                        // Copy the topic in the payload.
                        memcpy(tcp_client_unsubscribe_msg->payload, command_args[1].c_str(), MAX_TOPIC);
                        // Send the unsubscribe message to the server.
                        rc = (int) send(sockfd, tcp_client_unsubscribe_msg, sizeof(tcp_struct), 0);
                        DIE(rc < 0, "unsubscribe");
                        // Server sends unsubscribe confirmation.
                        int reply;
                        rc = (int) recv(sockfd, &reply, 1, 0);
                        DIE(rc < 0, "receive");

                        // Output success message.
                        if (reply == 0) {
                            cout << "Unsubscribed from topic " << command_args[1].c_str() << endl;
                        }
                        continue;
                    }
                } else {
                    struct tcp_struct *recv_msg = new tcp_struct;
                    memset(recv_msg, 0, sizeof(struct tcp_struct));
                    // Receive the message from the server.
                    rc = (int) recv(sockfd, recv_msg, sizeof(tcp_struct), 0);
                    DIE(rc < 0, "receive");
                    if (rc == 0) {
                        break;
                    } else {
                        if (recv_msg->type != 2) {
                            continue;
                        }
                    }
                    struct topic_udp *topic_info = (struct topic_udp *) recv_msg->payload;
                    memset(topic_info, 0, MAX_UDP_SIZE);
                    memcpy(topic_info->topic, recv_msg->payload, MAX_TOPIC-1);
                    memcpy(&topic_info->type, recv_msg->payload + MAX_TOPIC-1, sizeof(unsigned char));
                    memcpy(topic_info->payload, recv_msg->payload + MAX_TOPIC, MAX_UDP_PAYLOAD);
                    topic_info->payload[MAX_UDP_PAYLOAD-1] = '\0';

                    struct in_addr udp_addr{};
                    memset(&udp_addr, 0, sizeof(struct in_addr));
                    memcpy(&udp_addr, recv_msg->payload + sizeof(struct topic_udp), sizeof(struct in_addr));

                    uint16_t udp_port;
                    memcpy(&udp_port, recv_msg->payload + sizeof(struct topic_udp) + sizeof(in_addr), sizeof(uint16_t));
                    // Convert to host order.
                    udp_port = ntohs(udp_port);

                    // Handle int number.
                    if (topic_info->type == 0) {
                        uint8_t sign_byte;
                        uint32_t value;

                        // Get the sign.
                        memcpy(&sign_byte, topic_info->payload, sizeof(uint8_t));
                        // Get the number.
                        memcpy(&value, topic_info->payload + sizeof(uint8_t), sizeof(uint32_t));
                        // Convert to host order.
                        value = ntohl(value);

                        if (sign_byte == 1) {
                            value *= -1;
                        }

                        cout << inet_ntoa(udp_addr) << ":" << udp_port << " - " << topic_info->topic
                                << " - INT - " << (int) value << endl;
                    }

                    // Handle short real number.
                    if (topic_info->type == 1) {
                        uint16_t value;

                        // Get the number.
                        memcpy(&value, topic_info->payload, sizeof(uint16_t));
                        // Convert to host order.
                        value = ntohs(value);

                        cout << inet_ntoa(udp_addr) << ":" << udp_port << " - " << topic_info->topic
                                << " - SHORT_REAL - " << fixed << setprecision(2) << (float) value / 100.00 << endl;
                    }

                    // Handle float.
                    if (topic_info->type == 2) {
                        uint8_t sign_byte;
                        uint32_t concat_value;
                        uint8_t power;

                        // Get the sign byte.
                        memcpy(&sign_byte, topic_info->payload, sizeof(uint8_t));
                        // Get the number.
                        memcpy(&concat_value, topic_info->payload + sizeof(uint8_t), sizeof(uint32_t));
                        // Get the power.
                        memcpy(&power, topic_info->payload + sizeof(uint8_t) + sizeof(uint32_t), sizeof(uint8_t));

                        // Convert to host order.
                        float value = ntohl(concat_value);

                        for (int i = 0; i < power; i++) {
                            value /= 10;
                        }

                        if (sign_byte == 1) {
                            value *= -1;
                        }

                        cout << inet_ntoa(udp_addr) << ":" << udp_port << " - " << topic_info->topic
                                << " - FLOAT - " << fixed << setprecision(power) << value << endl;
                    }

                    // Handle string.
                    if (topic_info->type == 3) {
                        cout << inet_ntoa(udp_addr) << ":" << udp_port << " - " << topic_info->topic
                                << " - STRING - " << (char *) topic_info->payload << endl;
                    }
                }
            }
        }
    }
}