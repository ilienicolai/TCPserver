#include <iostream>
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <vector>
#include <algorithm>
#include <cstring>
#include <unordered_map>
#include "utils.h"

using namespace std;
string lowercase(string str) {

    // Iterate all characters, transform all to lowercase.
    for (auto& c : str) {
        c = (char) tolower(c);
    }
    return str;
}
int main(int argc, char *argv[]) {
    // Check number of arguments
    if (argc != 2) {
        cout << "Incorrect number of arguments" << endl;
        cout << "Expected ./server <port>" << endl;
        exit(0);
    }
    // Buffering disabled
    setvbuf(stdout, nullptr, _IONBF, BUFSIZ);

    uint16_t port;
    port = stoi(argv[1]);
    DIE(port == 0, "port");
    int rc;

    //Get udp socket to receive topics
    int recv_udp = socket(AF_INET, SOCK_DGRAM, 0);
    DIE(recv_udp < 0, "udp socket error");

    // Set fields to bind
    struct sockaddr_in *udp_addr = new sockaddr_in;
    socklen_t udp_len = sizeof(struct sockaddr_in);
    memset(udp_addr, 0, udp_len);
    udp_addr->sin_family = AF_INET;
    udp_addr->sin_port = htons(port);
    udp_addr->sin_addr.s_addr = INADDR_ANY;
    // Bind
    rc = bind(recv_udp, (const struct sockaddr *) udp_addr, sizeof(struct sockaddr_in));
    DIE(rc < 0, "bind udp failed");

    // Get tcp socket to accept connections from tcp clients
    int listen_tcp = socket(AF_INET, SOCK_STREAM, 0);
    DIE(listen_tcp < 0, "udp socket error");

    // Set fields to bind
    struct sockaddr_in tcp_addr;
    socklen_t tcp_len = sizeof(struct sockaddr_in);
    memset(&tcp_addr, 0, tcp_len);
    tcp_addr.sin_family = AF_INET;
    tcp_addr.sin_port = htons(port);
    tcp_addr.sin_addr.s_addr = INADDR_ANY;
    // Bind
    rc = bind(listen_tcp, (const struct sockaddr *) &tcp_addr, sizeof(struct sockaddr_in));
    DIE(rc < 0, "bind tcp failed");

    rc = listen(listen_tcp, MAX_CONNECTIONS);
    DIE(rc < 0, "listen");
    // Nagle's algorithm disabled
    int flag = 1;
    rc = setsockopt(listen_tcp, IPPROTO_TCP, TCP_NODELAY, (const void*) &flag, sizeof(int));
    DIE(rc < 0, "nagle");

    // Set pollfd initially with stdin, recv_udp, listen_tcp
    struct pollfd poll_fds[MAX_CONNECTIONS];
    int num_sockets = 3;
    poll_fds[0].fd = STDIN_FILENO;
    poll_fds[0].events = POLLIN;
    poll_fds[1].fd = recv_udp;
    poll_fds[1].events = POLLIN;
    poll_fds[2].fd = listen_tcp;
    poll_fds[2].events = POLLIN;

    // Map between tcp client and socket
    unordered_map<int, int> tcpid_socket;

    // Map between socket and tcp client
    unordered_map<int, int> socket_tcpid;

    // Map between topic and subscribers
    unordered_map<string, vector<int>> topic_subs;
    //cout << "Server started" << endl;
    bool loop = true;
    while(loop) {
        rc = poll(poll_fds, num_sockets, -1);
        DIE(rc < 0, "poll");

        for (int i = 0; i < num_sockets; i++) {
            if (poll_fds[i].revents & POLLIN) {
                if (poll_fds[i].fd == recv_udp) {
                    char buff[MAX_UDP_SIZE];
                    memset(buff, 0, MAX_UDP_SIZE);
                    auto *udp_topic = new sockaddr_in;
                    socklen_t udp_topic_len = sizeof(struct sockaddr_in);
                    rc = (int) recvfrom(recv_udp, buff, sizeof(buff), 0, (struct sockaddr *) udp_topic, &udp_topic_len);
                    DIE(rc < 0, "topic recv failed");
                    auto *subs_response = new tcp_struct;
                    memset(subs_response, 0, sizeof(struct tcp_struct));
                    subs_response->type = 2;
                    memcpy(subs_response->payload, buff, sizeof(struct topic_udp));
                    char *topic = new char[MAX_TOPIC];
                    memset(topic, 0, MAX_TOPIC);
                    memcpy(topic, (struct topic_udp*)buff, MAX_TOPIC-1);
                    if (topic_subs.find(topic) == topic_subs.end()) {
                        continue;
                    }
                    vector<int> subscribers = topic_subs[topic];
                    for (auto subs : subscribers) {
                        int subs_sock = tcpid_socket[subs];
                        if (subs_sock >= 0) {
                            rc = (int) send(subs_sock, subs_response, sizeof(struct tcp_struct), 0);
                            DIE(rc < 0, "subs response");
                        }
                    }
                    continue;
                }
                if (poll_fds[i].fd == listen_tcp) {
                    
                    // Disable Nagle's algorithm.
                    flag = 1;
                    rc = setsockopt(listen_tcp, IPPROTO_TCP, TCP_NODELAY, (char *) &flag, sizeof(int));
                    DIE(rc < 0, "nagle");
                    auto *subscriber_addr = new sockaddr_in;
                    socklen_t subscriber_addr_len = sizeof(struct sockaddr_in);
                    //cout << "Waiting for new client to connect." << endl;
                    int subscriber = accept(listen_tcp, (struct sockaddr *)subscriber_addr, &subscriber_addr_len);
                    DIE(subscriber < 0, "subscribe");
                    // New tcp message
                    auto *recv_subs_msg = new tcp_struct;
                    rc = (int) recv(subscriber, recv_subs_msg, sizeof(tcp_struct), 0);
                    DIE(rc < 0, "tcp receive");
                    auto *subscriber_id_chr = (char *) recv_subs_msg->payload;
                    uint32_t subscriber_id;
                    subscriber_id = (uint32_t) atoi(subscriber_id_chr);
                    if (tcpid_socket.find(subscriber_id) != tcpid_socket.end() && tcpid_socket[subscriber_id] != -1) {

                        // Close the connection.
                        close(subscriber);

                        // Output an error message.
                        cout << "Client " << subscriber_id << " already connected.\0" << endl;
                        continue;
                    }
                    if (tcpid_socket.find(subscriber_id) == tcpid_socket.end()) {

                        // If there wasn't a previous client that had this ID, create a new entry in the map.
                        tcpid_socket.insert(make_pair(subscriber_id, subscriber));
                        socket_tcpid.insert(make_pair(subscriber, subscriber_id));
                    }
                    else {

                        // There was a previous client using this ID.
                        tcpid_socket[subscriber_id] = subscriber;
                        socket_tcpid.insert(make_pair(subscriber, subscriber_id));
                    }
                    poll_fds[num_sockets].fd = subscriber;
                    poll_fds[num_sockets].events = POLLIN;
                    num_sockets++;

                    // Print the "new client connected" message.
                    auto *string_address = inet_ntoa(subscriber_addr->sin_addr);
                    auto string_port = ntohs(subscriber_addr->sin_port);

                    cout << "New client C" << subscriber_id << " connected from " <<
                         string_address << ":" << string_port << endl;
                    continue;
                }
                if (poll_fds[i].fd == STDIN_FILENO) {
                    string command;
                    cin>>command;
                    // Convert all character to lowercase.
                    command = lowercase(command);

                    // Exit command was entered.
                    if (command == "exit") {

                        // Close all connected clients.
                        for (int j = 0; j < num_sockets; j++) {
                            if (j != 2)
                                close(poll_fds[j].fd);
                        }

                        // Stop the while loop.
                        loop = false;
                        break;
                    }

                    continue;
                }
                // Handle disconects
                auto *recv_subs_message = new tcp_struct;
                memset(recv_subs_message, 0, sizeof(struct tcp_struct));
                rc = (int) recv(poll_fds[i].fd, recv_subs_message, sizeof(tcp_struct), 0);
                DIE(rc < 0, "subs msg");
                if (rc == 0) {
                     // Client has disconnected.
                    cout << "Client " << socket_tcpid[poll_fds[i].fd] << " disconnected." << endl;
                    tcpid_socket[socket_tcpid[poll_fds[i].fd]] = -1;
                    socket_tcpid.erase(poll_fds[i].fd);
                    // eliminare socket din poll_fds
                    close(poll_fds[i].fd);
                    for (int j = i; j < num_sockets - 1; j++) {
                        poll_fds[j] = poll_fds[j + 1];
                    }
                }
                // Handle unsubscribe
                if (recv_subs_message->type == -1) {
                    if (topic_subs.find(recv_subs_message->payload) != topic_subs.end()) {

                        // Get the subscribed clients to the topic.
                        auto subscribers = topic_subs[recv_subs_message->payload];

                        // Find the client's ID in the subscribers vector.
                        auto client_id = find(subscribers.begin(), subscribers.end(), socket_tcpid[poll_fds[i].fd]);

                        // If the client can be found in the list of subscribers.
                        if (client_id != subscribers.end()) {
                            // Remove the client from the list of subscribers.
                            subscribers.erase(client_id);
                        }

                        // Update the topic's subscribers with the new list.
                        topic_subs[recv_subs_message->payload] = subscribers;
                        // Send unsubscribe success to the client.
                        flag = 0;
                        rc = (int) send(poll_fds[i].fd, &flag, 4, 0);
                        DIE(rc < 0, "unsubscribe send");
                    }
                }
                // Type is 1, client wants to subscribe.
                if (recv_subs_message->type == 1) {
                    // cout << recv_subs_message->payload << endl;
                    // Check if the topic has any subscribers.
                    if (topic_subs.find(recv_subs_message->payload) != topic_subs.end()) {

                        // Get the subscribed clients to the topic.
                        auto subscribers = topic_subs[recv_subs_message->payload];

                        // Find the client's ID in the subscribers vector.
                        auto client_id = find(subscribers.begin(), subscribers.end(), socket_tcpid[poll_fds[i].fd]);

                        // If the client is not subscribed, add it to the list of subscribers.
                        if (client_id == subscribers.end()) {
                            subscribers.push_back(socket_tcpid[poll_fds[i].fd]);
                        }

                        // Update the topic's subscribers with the new list.
                        topic_subs[recv_subs_message->payload] = subscribers;
                    }
                    else {
                        // Topic does not have any subscribers, create a new list.
                        vector<int> subscribers;
                        // Add the client to the new list of subscribers.
                        subscribers.push_back(socket_tcpid[poll_fds[i].fd]);

                        // Convert the topic's name to string.
                        auto string_topic = string(recv_subs_message->payload);
                        // Add the new topic and list of subscribers to the topic_clients map.
                        topic_subs.insert(make_pair(string_topic, subscribers));
                    }
                    // Send subscribe success to client.
                    flag = 1;
                    rc = (int) send(poll_fds[i].fd, &flag, 4, 0);
                    DIE(rc < 0, "subscribe send");
                }
            }
        }
    }
    // Close the server's udp and tcp sockets.
    close(listen_tcp);
    close(recv_udp);

    return 0;
}

